package com.sparkai.modfixer;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 41;
    private TextView status, output;
    private Uri selectedUri;
    private String selectedName = "Файл не выбран";
    private final int bg = Color.rgb(12, 18, 28);
    private final int panel = Color.rgb(24, 34, 48);
    private final int green = Color.rgb(60, 220, 145);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 30, 24, 24);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("✦ SparkAI ModFixer");
        title.setTextColor(green); title.setTextSize(26); title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Minecraft AI Developer • Android");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 8, 0, 22); root.addView(subtitle);

        Button pick = button("Выбрать JAR или лог");
        root.addView(pick);
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_FILE);
        });

        status = new TextView(this);
        status.setText(selectedName); status.setTextColor(Color.WHITE); status.setTextSize(15);
        status.setPadding(12, 18, 12, 18); root.addView(status);

        Button inspect = button("Проверить файл локально");
        root.addView(inspect);
        inspect.setOnClickListener(v -> inspectFile());

        Button logHelp = button("Как получить лог ошибки");
        root.addView(logHelp);
        logHelp.setOnClickListener(v -> showLogHelp());

        TextView heading = new TextView(this);
        heading.setText("Результат диагностики");
        heading.setTextColor(green); heading.setTextSize(18);
        heading.setPadding(0, 22, 0, 8); root.addView(heading);

        output = new TextView(this);
        output.setTextColor(Color.WHITE); output.setTextSize(14);
        output.setBackgroundColor(panel); output.setPadding(16,16,16,16);
        output.setText("Выбери JAR или текстовый лог, затем запусти проверку.");
        root.addView(output);

        TextView note = new TextView(this);
        note.setText("\nВерсия 0.1 • Локальная диагностика прототипа\nОблачный ИИ и автоматическая пересборка JAR пока не подключены.");
        note.setTextColor(Color.GRAY); note.setTextSize(12); root.addView(note);
        setContentView(scroll);
    }

    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(31, 110, 82)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 7, 0, 7); b.setLayoutParams(p); return b;
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == PICK_FILE && res == RESULT_OK && data != null) {
            selectedUri = data.getData();
            selectedName = selectedUri.getLastPathSegment();
            status.setText("Выбран файл: " + selectedName);
            output.setText("Файл выбран. Нажми «Проверить файл локально».");
        }
    }

    private void inspectFile() {
        if (selectedUri == null) {
            output.setText("Сначала выбери файл через системный проводник Android.");
            return;
        }
        String name = selectedName == null ? "" : selectedName.toLowerCase(Locale.ROOT);
        try {
            if (name.endsWith(".jar") || name.endsWith(".zip")) inspectJar();
            else inspectText();
        } catch (Exception e) {
            output.setText("Не удалось прочитать файл.\nПричина: " + e.getClass().getSimpleName() + ": " + e.getMessage()
                + "\n\nПроверь, что файл доступен и не повреждён.");
        }
    }

    private void inspectJar() throws Exception {
        StringBuilder report = new StringBuilder();
        HashSet<String> entries = new HashSet<>();
        ArrayList<String> warnings = new ArrayList<>();
        boolean fabric = false, forge = false, pluginYml = false;
        int count = 0;
        long totalBytes = 0;
        final int MAX_ENTRIES = 10000;
        final long MAX_TOTAL_UNPACKED = 200L * 1024L * 1024L;
        final long MAX_ENTRY_BYTES = 50L * 1024L * 1024L;
        byte[] buffer = new byte[8192];
        try (InputStream in = getContentResolver().openInputStream(selectedUri);
             ZipInputStream zip = new ZipInputStream(new BufferedInputStream(in))) {
            ZipEntry e;
            while ((e = zip.getNextEntry()) != null) {
                count++;
                if (count > MAX_ENTRIES) {
                    warnings.add("Превышен лимит записей архива (10 000); проверка остановлена для защиты от ZIP-бомбы.");
                    break;
                }
                String entryName = e.getName() == null ? "" : e.getName();
                entries.add(entryName);
                String lower = entryName.toLowerCase(Locale.ROOT).replace('\\', '/');
                if (lower.equals("fabric.mod.json")) fabric = true;
                if (lower.equals("meta-inf/mods.toml")) forge = true;
                if (lower.equals("plugin.yml") || lower.equals("paper-plugin.yml")) pluginYml = true;
                if (lower.startsWith("/") || lower.contains("../") || lower.equals(".."))
                    warnings.add("Подозрительный путь внутри архива: " + entryName);
                if (lower.endsWith(".bat") || lower.endsWith(".cmd") || lower.endsWith(".ps1") ||
                    lower.endsWith(".sh") || lower.endsWith(".apk") || lower.endsWith(".exe") ||
                    lower.endsWith(".dll") || lower.endsWith(".so"))
                    warnings.add("Исполняемый/скриптовый файл внутри архива (сам по себе не доказывает вредоносность): " + entryName);

                long entryBytes = 0;
                ByteArrayOutputStream textCandidate = new ByteArrayOutputStream();
                boolean maybeText = lower.endsWith(".json") || lower.endsWith(".yml") || lower.endsWith(".yaml") ||
                    lower.endsWith(".toml") || lower.endsWith(".properties") || lower.endsWith(".txt") ||
                    lower.endsWith(".js") || lower.endsWith(".html") || lower.endsWith(".xml");
                int n;
                while ((n = zip.read(buffer)) != -1) {
                    entryBytes += n;
                    totalBytes += n;
                    if (entryBytes > MAX_ENTRY_BYTES || totalBytes > MAX_TOTAL_UNPACKED) {
                        warnings.add("Архив превысил безопасный лимит распакованных данных; проверка остановлена.");
                        break;
                    }
                    if (maybeText && textCandidate.size() < 1024 * 1024) {
                        int keep = (int)Math.min(n, 1024L * 1024L - textCandidate.size());
                        if (keep > 0) textCandidate.write(buffer, 0, keep);
                    }
                }
                if (entryBytes > MAX_ENTRY_BYTES || totalBytes > MAX_TOTAL_UNPACKED) break;
                if (maybeText) {
                    String content = textCandidate.toString("UTF-8").toLowerCase(Locale.ROOT);
                    if (content.contains("runtime.getruntime().exec") || content.contains("processbuilder(") ||
                        content.contains("powershell -enc") || content.contains("curl ") && content.contains("| sh")) {
                        warnings.add("Подозрительный шаблон запуска команд/загрузки в " + entryName + ". Требуется ручная проверка.");
                    }
                }
                zip.closeEntry();
            }
        }
        report.append("ЛОКАЛЬНАЯ ПРОВЕРКА JAR/ZIP\n\n");
        report.append("Проверено записей: ").append(count).append("\n");
        report.append("Прочитано распакованных данных: ").append(totalBytes / 1024).append(" КБ\n");
        if (count == 0) report.append("ОШИБКА: архив пустой или не является корректным ZIP/JAR.\n");
        if (fabric) report.append("✓ Найден fabric.mod.json (вероятно Fabric-мод).\n");
        if (forge) report.append("✓ Найден META-INF/mods.toml (вероятно Forge-мод).\n");
        if (pluginYml) report.append("✓ Найден plugin.yml/paper-plugin.yml (вероятно Bukkit/Paper-плагин).\n");
        if (!fabric && !forge && !pluginYml) report.append("⚠ Не найдены стандартные метаданные Fabric, Forge или Bukkit/Paper.\n");
        if (entries.contains("META-INF/MANIFEST.MF")) report.append("✓ Есть манифест META-INF/MANIFEST.MF.\n");
        else report.append("⚠ Нет META-INF/MANIFEST.MF (не всегда является ошибкой).\n");
        report.append("\nПРЕДУПРЕЖДЕНИЯ БЕЗОПАСНОСТИ: ").append(warnings.size()).append("\n");
        if (warnings.isEmpty()) report.append("Явные подозрительные признаки этим простым сканером не обнаружены. Это НЕ гарантирует безопасность файла.\n");
        else for (String warning : warnings) report.append("⚠ ").append(warning).append("\n");
        report.append("\nЗащита: приложение не запускает найденный код. Сканер ограничивает число записей и объём распаковки, но не заменяет антивирус и полноценный статический анализ.");
        output.setText(report.toString());
    }

    private void inspectText() throws Exception {
        StringBuilder text = new StringBuilder();
        try (InputStream in = getContentResolver().openInputStream(selectedUri);
             BufferedReader r = new BufferedReader(new InputStreamReader(in))) {
            String line; int n = 0;
            while ((line = r.readLine()) != null && n++ < 5000) text.append(line).append('\n');
        }
        String s = text.toString();
        StringBuilder out = new StringBuilder("АНАЛИЗ ТЕКСТОВОГО ЛОГА\n\n");
        String[] needles = {"Caused by:", "Exception", "ERROR", "NoSuchMethodError", "NoClassDefFoundError",
                "ClassNotFoundException", "IncompatibleClassChangeError", "Mixin apply failed",
                "requires fabric loader", "Incompatible mods found"};
        int found = 0;
        for (String needle : needles) {
            int at = s.indexOf(needle);
            if (at >= 0) {
                found++;
                int start = Math.max(0, at - 180), end = Math.min(s.length(), at + 500);
                out.append("Найден маркер: ").append(needle).append("\n");
                out.append(s.substring(start, end)).append("\n\n---\n\n");
            }
        }
        if (found == 0) out.append("Известные маркеры ошибок не найдены. Попробуй загрузить latest.log или crash-report.\n");
        else out.append("Найдено категорий маркеров: ").append(found).append(". Фрагменты выше требуют анализа; автоматическое исправление пока не выполняется.");
        output.setText(out.toString());
    }

    private void showLogHelp() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("Где найти лог Minecraft")
            .setMessage("Открой папку игры или лаунчера и найди logs/latest.log. После вылета также проверь папку crash-reports. Выбери файл через кнопку в приложении.\n\nВ разных Android-лаунчерах путь к папке игры отличается.")
            .setPositiveButton("Понятно", null).show();
    }
}
